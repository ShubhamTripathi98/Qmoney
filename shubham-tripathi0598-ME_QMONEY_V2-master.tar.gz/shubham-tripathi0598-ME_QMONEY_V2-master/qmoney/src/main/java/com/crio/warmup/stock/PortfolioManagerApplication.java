
package com.crio.warmup.stock;


import com.crio.warmup.stock.dto.*;
import com.crio.warmup.stock.log.UncaughtExceptionHandler;
import com.fasterxml.jackson.annotation.JacksonInject.Value;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.web.client.RestTemplate;
import java.nio.file.Files;
import java.time.LocalDate;


public class PortfolioManagerApplication {

  private  static String token = "279ea24ef64c41da0536b04d684e904eb74137bd";

  

  public static List<String> mainReadFile(String[] args) throws IOException, URISyntaxException {
    
    List <PortfolioTrade> portfolioTrades = readTradesFromJson(args[0]);
    List<String> symbols = new ArrayList<>();
    for(PortfolioTrade trade : portfolioTrades){
      symbols.add(trade.getSymbol());
    }
    return symbols;
  }

  private static void printJsonObject(Object object) throws IOException {
    Logger logger = Logger.getLogger(PortfolioManagerApplication.class.getCanonicalName());
    ObjectMapper mapper = new ObjectMapper();
    logger.info(mapper.writeValueAsString(object));
}

  private static ObjectMapper getObjectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper;
  }  

  private static File resolveFileFromResources(String filename) throws URISyntaxException {
    return Paths.get(
        Thread.currentThread().getContextClassLoader().getResource(filename).toURI()).toFile();
  
  }
 

  static List<String> debugOutputs() {

    String valueOfArgument0 = "trades.json";
    String resultOfResolveFilePathArgs0 = "trades.json";
    String toStringOfObjectMapper = "ObjectMapper";
    String functionNameFromTestFileInStackTrace = "mainReadFile";
    String lineNumberFromTestFileInStackTrace = "";


    return Arrays.asList(new String[]{valueOfArgument0, resultOfResolveFilePathArgs0,
       toStringOfObjectMapper, functionNameFromTestFileInStackTrace,
       lineNumberFromTestFileInStackTrace});
  }









  // TODO: CRIO_TASK_MODULE_REST_API
  //  Find out the closing price of each stock on the end_date and return the list
  //  of all symbols in ascending order by its close value on end date.

  // Note:
  // 1. You may have to register on Tiingo to get the api_token.
  // 2. Look at args parameter and the module instructions carefully.
  // 2. You can copy relevant code from #mainReadFile to parse the Json.
  // 3. Use RestTemplate#getForObject in order to call the API,
  //    and deserialize the results in List<Candle>

  public static List<String> mainReadQuotes(String[] args) throws IOException, URISyntaxException {

     List<PortfolioTrade> trades = readTradesFromJson(args[0]);
     RestTemplate restTemplate = new RestTemplate();
     List<TotalReturnsDto> totalReturnsDtos = new ArrayList<>();
     LocalDate endDate = LocalDate.parse(args[1]);
     for(PortfolioTrade trade: trades){
      Candle[] candles = restTemplate.getForObject(prepareUrl(trade, endDate, token), TiingoCandle[].class);
      totalReturnsDtos.add(new TotalReturnsDto(trade.getSymbol(), candles[candles.length-1].getClose()));

     }
     Collections.sort(totalReturnsDtos);
     List<String> results = new ArrayList<>();
     for(TotalReturnsDto dto: totalReturnsDtos){
      results.add(dto.getSymbol());
     }
    return results;
  }

  // TODO:
  //  After refactor, make sure that the tests pass by using these two commands
  //  ./gradlew test --tests PortfolioManagerApplicationTest.readTradesFromJson
  //  ./gradlew test --tests PortfolioManagerApplicationTest.mainReadFile
  public static List<PortfolioTrade> readTradesFromJson(String filename) throws IOException, URISyntaxException {
    File inputFile = resolveFileFromResources(filename);
    PortfolioTrade[] portfolioTrades = getObjectMapper().readValue(inputFile, PortfolioTrade[].class);

    return Arrays.asList(portfolioTrades);
}
// TODO:
  //  Build the Url using given parameters and use this function in your code to cann the API.
  public static String prepareUrl(PortfolioTrade trade, LocalDate endDate, String token) {
    String startDate = trade.getPurchaseDate().toString(); // Assuming trade.getPurchaseDate() is LocalDate
    String formattedEndDate = endDate.toString();
    String url = "https://api.tiingo.com/tiingo/daily/" + trade.getSymbol() + 
                 "/prices?startDate=" + startDate + "&endDate=" + formattedEndDate + 
                 "&token=" + token;
    return url;
  }










  public static void main(String[] args) throws Exception {
    Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler());
    ThreadContext.put("runId", UUID.randomUUID().toString());

    printJsonObject(mainReadFile(args));


    // printJsonObject(mainReadQuotes(args));


  }
}

