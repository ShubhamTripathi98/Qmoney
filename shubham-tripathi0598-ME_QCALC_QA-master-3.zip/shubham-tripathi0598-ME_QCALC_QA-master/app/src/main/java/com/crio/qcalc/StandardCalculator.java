package com.crio.qcalc;

public class StandardCalculator {
    protected double result;

    public double getResult(){
        return result;
    }




    public void setResult(int value){
        if(value!=0)
        return;
        this.result = value;

    }


public final void add(double d, double e){
    double result = d + e;
    if((result == Double.MAX_VALUE) || (result == Double.POSITIVE_INFINITY)){

        throw new ArithmeticException("Double overflow");
    }
    this.result = result;
}


public final void subtract(double d, double e){
    double result = d - e;
    if((result == -Double.MAX_VALUE) || (result == Double.NEGATIVE_INFINITY)){

        throw new ArithmeticException("Double overflow");

    }

    this.result = result;

}


public final void multiply(double num1, double num2){

    if (num1 > 0 && num2 > 0 && num1 > Double.MAX_VALUE / num2) {
        throw new ArithmeticException("Positive overflow");
    } else if (num1 > 0 && num2 < 0 && num1 > Double.MIN_VALUE / num2) {
        throw new ArithmeticException("Negative overflow");
    } else if (num1 < 0 && num2 > 0 && num1 < Double.MIN_VALUE / num2) {
        throw new ArithmeticException("Negative overflow");
    } else if (num1 < 0 && num2 < 0 && num1 < Double.MAX_VALUE / num2) {
        throw new ArithmeticException("Positive overflow");
    }


    
    double result = num1 * num2;

    // Check for infinity which indicates overflow
    if (Double.isInfinite(result)) {
        throw new ArithmeticException("Overflow resulting in infinity");
    }

    this.result = result;

}

public final void divide(double num1, double num2){


    if(num2 == 0.0){

        throw new ArithmeticException("Divide By Zero");

    }

    result = num1/num2;
}


    public static void getVersion(){
        System.out.println("Standard Calculator 1.0");
    }






}
